<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'admin' );

/** MySQL database password */
define( 'DB_PASSWORD', 'password123' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '=*F=(%Dn5$,I>DG.d9:1eokKuzAnO2|++D{/}0L1atQkEka(@:MP#rVY8J;x*e6@' );
define( 'SECURE_AUTH_KEY',  'S[zrnLy9Q~1kF>^n{XTf~s4ho_g7WZ_B7gGA}o<c)JeBt;r%RL)(XDeM6rGDm)k@' );
define( 'LOGGED_IN_KEY',    '4.4~X[N3Z&nuc`}4dHctDg(lfG]`!86}?aE>B`DD,Kd7;;L?8!rm/@kKsMdv4T-t' );
define( 'NONCE_KEY',        '&uDmZ]M&u@Pt.{s:4VX`@#<e[WNg X.m~jr5]oL_.c5o$V8Ht<Bhs~bd($XE5J04' );
define( 'AUTH_SALT',        '0AEv|bX(.Ss}&5SoL}+TdVt)JW{YgQ,Hy8?2^3JO?Y!>C7T /:q+eI<p/EqlaO<s' );
define( 'SECURE_AUTH_SALT', ')>W*gLFNIu%QyKAKZDHkWO.ka3|)ZYwX(qD7{,uw[a$6.w{UX#S5NhxL 40EE$I.' );
define( 'LOGGED_IN_SALT',   '`|/L`8qPDg8nflaOYss]^dem26G<K]~|pH=<=}Y67ac:1oj9)2UvLU,+*>g|)rSH' );
define( 'NONCE_SALT',       'K[7h;hR>BROsxA+r`nX(Oa><rRtR-go!7lO|AK4ABKe[Vx-^D$t:|VRX6d?eR)S0' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
